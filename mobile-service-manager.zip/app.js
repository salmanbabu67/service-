// Global variables for data storage
let serviceRecords = [];
let serviceCounter = 3; // Start from 3 since we have sample data
let currentBillService = null;
let billItems = [];

// Sample data
const sampleServices = [
  {
    service_id: 'SRV001',
    date: '2025-10-23',
    customer_name: 'Rahul Kumar',
    mobile_number: '9876543210',
    address: '123 Main Street, Mumbai',
    mobile_brand: 'Samsung',
    model: 'Galaxy S21',
    imei1: '123456789012345',
    imei2: '543210987654321',
    issue: 'Display broken and touch not working',
    service_type: ['Display'],
    mobile_condition: 'ON',
    accessories: ['SIM Tray', 'Back Cover'],
    received_by: 'Avinash',
    estimated_delivery: '2025-10-25',
    warranty: '3',
    from_date: '2025-10-23',
    to_date: '2026-01-23'
  },
  {
    service_id: 'SRV002',
    date: '2025-10-23',
    customer_name: 'Priya Sharma',
    mobile_number: '8765432109',
    address: '456 Park Avenue, Delhi',
    mobile_brand: 'Apple',
    model: 'iPhone 13',
    imei1: '987654321098765',
    imei2: '123456789876543',
    issue: 'Battery draining fast, not charging properly',
    service_type: ['Battery', 'Charger'],
    mobile_condition: 'Good',
    accessories: ['SIM Tray'],
    received_by: 'Aryan',
    estimated_delivery: '2025-10-24',
    warranty: '6',
    from_date: '2025-10-23',
    to_date: '2026-04-23'
  }
];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
  // Add sample data to records
  serviceRecords = [...sampleServices];
  
  // Set current date
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('serviceDate').value = today;
  
  // Initialize form event listeners
  initializeFormListeners();
  
  // Show service section by default
  showSection('service');
});

// Initialize form event listeners
function initializeFormListeners() {
  // Service form submission
  document.getElementById('serviceForm').addEventListener('submit', handleServiceSubmission);
  
  // Other service checkbox handler
  document.getElementById('otherServiceCheck').addEventListener('change', function() {
    const otherInput = document.getElementById('otherService');
    otherInput.disabled = !this.checked;
    if (!this.checked) {
      otherInput.value = '';
    }
  });
  
  // Warranty period change handler
  document.querySelectorAll('input[name="warranty"]').forEach(radio => {
    radio.addEventListener('change', calculateWarrantyDates);
  });
  
  // Image upload handlers
  document.getElementById('frontImage').addEventListener('change', function() {
    previewImage(this, 'frontPreview');
  });
  
  document.getElementById('backImage').addEventListener('change', function() {
    previewImage(this, 'backPreview');
  });
}

// Show/hide sections
function showSection(sectionName) {
  // Hide all sections
  document.querySelectorAll('.section').forEach(section => {
    section.classList.remove('active');
  });
  
  // Remove active class from all tabs
  document.querySelectorAll('.tab-button').forEach(tab => {
    tab.classList.remove('active');
  });
  
  // Show selected section
  if (sectionName === 'service') {
    document.getElementById('serviceSection').classList.add('active');
    document.getElementById('serviceTab').classList.add('active');
  } else if (sectionName === 'billing') {
    document.getElementById('billingSection').classList.add('active');
    document.getElementById('billingTab').classList.add('active');
  }
}

// Generate next service ID
function generateServiceId() {
  return `SRV${String(serviceCounter).padStart(3, '0')}`;
}

// Handle service form submission
function handleServiceSubmission(e) {
  e.preventDefault();
  
  // Validate form
  if (!validateServiceForm()) {
    return;
  }
  
  // Collect form data
  const formData = collectServiceFormData();
  
  // Add to service records
  serviceRecords.push(formData);
  
  // Show success message
  showSuccessMessage(formData.service_id);
  
  // Update service counter and display
  serviceCounter++;
  updateServiceIdDisplay();
  
  // Clear form
  clearServiceForm();
}

// Validate service form
function validateServiceForm() {
  let isValid = true;
  const requiredFields = [
    'serviceDate', 'customerName', 'mobileNumber', 'mobileBrand', 
    'model', 'imei1', 'issue', 'mobileCondition', 'receivedBy', 'estimatedDelivery'
  ];
  
  // Clear previous error messages
  document.querySelectorAll('.error-message').forEach(msg => msg.remove());
  
  // Check required fields
  requiredFields.forEach(fieldId => {
    const field = document.getElementById(fieldId);
    if (!field.value.trim()) {
      showFieldError(field, 'This field is required');
      isValid = false;
    }
  });
  
  // Validate mobile number
  const mobileNumber = document.getElementById('mobileNumber').value;
  if (mobileNumber && !/^[0-9]{10}$/.test(mobileNumber)) {
    showFieldError(document.getElementById('mobileNumber'), 'Mobile number must be 10 digits');
    isValid = false;
  }
  
  // Validate IMEI numbers
  const imei1 = document.getElementById('imei1').value;
  if (imei1 && !/^[0-9]{15}$/.test(imei1)) {
    showFieldError(document.getElementById('imei1'), 'IMEI must be 15 digits');
    isValid = false;
  }
  
  const imei2 = document.getElementById('imei2').value;
  if (imei2 && !/^[0-9]{15}$/.test(imei2)) {
    showFieldError(document.getElementById('imei2'), 'IMEI must be 15 digits');
    isValid = false;
  }
  
  // Validate service type selection
  const serviceTypes = document.querySelectorAll('input[name="serviceType"]:checked');
  if (serviceTypes.length === 0) {
    const serviceTypeGroup = document.querySelector('.checkbox-group');
    showFieldError(serviceTypeGroup.parentElement, 'Please select at least one service type');
    isValid = false;
  }
  
  // Validate warranty selection
  const warranty = document.querySelector('input[name="warranty"]:checked');
  if (!warranty) {
    const warrantyGroup = document.querySelector('.radio-group');
    showFieldError(warrantyGroup.parentElement, 'Please select warranty period');
    isValid = false;
  }
  
  return isValid;
}

// Show field error
function showFieldError(field, message) {
  const errorDiv = document.createElement('div');
  errorDiv.className = 'error-message';
  errorDiv.style.color = 'var(--color-error)';
  errorDiv.style.fontSize = 'var(--font-size-sm)';
  errorDiv.style.marginTop = 'var(--space-4)';
  errorDiv.textContent = message;
  
  field.parentElement.appendChild(errorDiv);
  field.style.borderColor = 'var(--color-error)';
}

// Collect service form data
function collectServiceFormData() {
  const serviceId = generateServiceId();
  
  // Get selected service types
  const serviceTypes = [];
  document.querySelectorAll('input[name="serviceType"]:checked').forEach(checkbox => {
    if (checkbox.value === 'Others') {
      const otherValue = document.getElementById('otherService').value.trim();
      if (otherValue) {
        serviceTypes.push(otherValue);
      }
    } else {
      serviceTypes.push(checkbox.value);
    }
  });
  
  // Get selected accessories
  const accessories = [];
  document.querySelectorAll('input[name="accessories"]:checked').forEach(checkbox => {
    accessories.push(checkbox.value);
  });
  
  // Get warranty period and calculate dates
  const warrantyPeriod = document.querySelector('input[name="warranty"]:checked').value;
  const fromDate = document.getElementById('serviceDate').value;
  const toDate = calculateWarrantyEndDate(fromDate, parseInt(warrantyPeriod));
  
  return {
    service_id: serviceId,
    date: document.getElementById('serviceDate').value,
    customer_name: document.getElementById('customerName').value.trim(),
    mobile_number: document.getElementById('mobileNumber').value.trim(),
    address: document.getElementById('address').value.trim(),
    mobile_brand: document.getElementById('mobileBrand').value.trim(),
    model: document.getElementById('model').value.trim(),
    imei1: document.getElementById('imei1').value.trim(),
    imei2: document.getElementById('imei2').value.trim(),
    issue: document.getElementById('issue').value.trim(),
    service_type: serviceTypes,
    mobile_condition: document.getElementById('mobileCondition').value,
    accessories: accessories,
    received_by: document.getElementById('receivedBy').value,
    estimated_delivery: document.getElementById('estimatedDelivery').value,
    warranty: warrantyPeriod,
    from_date: fromDate,
    to_date: toDate
  };
}

// Calculate warranty end date
function calculateWarrantyEndDate(fromDate, months) {
  const date = new Date(fromDate);
  date.setMonth(date.getMonth() + months);
  return date.toISOString().split('T')[0];
}

// Calculate warranty dates when period changes
function calculateWarrantyDates() {
  const warrantyRadio = document.querySelector('input[name="warranty"]:checked');
  if (warrantyRadio) {
    const fromDate = document.getElementById('serviceDate').value;
    if (fromDate) {
      const months = parseInt(warrantyRadio.value);
      const toDate = calculateWarrantyEndDate(fromDate, months);
      
      document.getElementById('fromDate').value = fromDate;
      document.getElementById('toDate').value = toDate;
    }
  }
}

// Preview uploaded images
function previewImage(input, previewId) {
  const preview = document.getElementById(previewId);
  
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    
    reader.onload = function(e) {
      preview.innerHTML = `<img src="${e.target.result}" alt="Preview">`;
      preview.classList.add('has-image');
    };
    
    reader.readAsDataURL(input.files[0]);
  } else {
    preview.innerHTML = '';
    preview.classList.remove('has-image');
  }
}

// Show success message
function showSuccessMessage(serviceId) {
  const successDiv = document.getElementById('successMessage');
  const serviceIdSpan = document.getElementById('submittedServiceId');
  
  serviceIdSpan.textContent = serviceId;
  successDiv.classList.remove('hidden');
  
  // Hide message after 5 seconds
  setTimeout(() => {
    successDiv.classList.add('hidden');
  }, 5000);
}

// Update service ID display
function updateServiceIdDisplay() {
  document.getElementById('currentServiceId').textContent = generateServiceId();
}

// Clear service form
function clearServiceForm() {
  if (confirm('Are you sure you want to clear the form?')) {
    document.getElementById('serviceForm').reset();
    
    // Clear image previews
    document.getElementById('frontPreview').innerHTML = '';
    document.getElementById('frontPreview').classList.remove('has-image');
    document.getElementById('backPreview').innerHTML = '';
    document.getElementById('backPreview').classList.remove('has-image');
    
    // Reset other service input
    document.getElementById('otherService').disabled = true;
    
    // Clear error messages
    document.querySelectorAll('.error-message').forEach(msg => msg.remove());
    document.querySelectorAll('.form-control').forEach(field => {
      field.style.borderColor = '';
    });
    
    // Set current date
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('serviceDate').value = today;
    
    // Clear warranty dates
    document.getElementById('fromDate').value = '';
    document.getElementById('toDate').value = '';
  }
}

// Search for service
function searchService() {
  const searchValue = document.getElementById('searchInput').value.trim();
  
  if (!searchValue) {
    alert('Please enter a Service ID or Mobile Number');
    return;
  }
  
  // Search in service records
  const service = serviceRecords.find(record => 
    record.service_id.toLowerCase() === searchValue.toLowerCase() || 
    record.mobile_number === searchValue
  );
  
  if (service) {
    displayServiceDetails(service);
    generateBillPreview(service);
  } else {
    alert('Service not found. Please check the Service ID or Mobile Number.');
    hideServiceDetails();
  }
}

// Display service details
function displayServiceDetails(service) {
  const serviceDetailsDiv = document.getElementById('serviceDetails');
  const serviceInfoDiv = document.getElementById('serviceInfo');
  
  serviceInfoDiv.innerHTML = `
    <div class="service-info-grid">
      <div><strong>Service ID:</strong> ${service.service_id}</div>
      <div><strong>Date:</strong> ${service.date}</div>
      <div><strong>Customer:</strong> ${service.customer_name}</div>
      <div><strong>Mobile:</strong> ${service.mobile_number}</div>
      <div><strong>Brand:</strong> ${service.mobile_brand}</div>
      <div><strong>Model:</strong> ${service.model}</div>
      <div><strong>Issue:</strong> ${service.issue}</div>
      <div><strong>Warranty:</strong> ${service.warranty} months (${service.from_date} to ${service.to_date})</div>
    </div>
  `;
  
  serviceDetailsDiv.classList.remove('hidden');
  currentBillService = service;
}

// Hide service details
function hideServiceDetails() {
  document.getElementById('serviceDetails').classList.add('hidden');
  document.getElementById('billGeneration').classList.add('hidden');
  currentBillService = null;
}

// Generate bill preview
function generateBillPreview(service) {
  // Initialize bill items with empty array
  billItems = [
    { item: '', breakout: '', price: 0, quantity: 1, total: 0 }
  ];
  
  const billPreview = document.getElementById('billPreview');
  
  billPreview.innerHTML = `
    <div class="bill">
      <div class="bill-header">
        <div class="bill-title">BILL</div>
        <div class="shop-info">
          <strong>MILAYAN MULTI BRAND MOBILE &amp; LAPTOP SERVICE</strong><br>
          Shop Address Line 1, Line 2<br>
          Contact: +91-XXXXXXXXXX<br>
          GSTIN: XXXXXXXXXXXX (if applicable)
        </div>
      </div>
      
      <div class="bill-info">
        <div><strong>Service No:</strong> ${service.service_id}</div>
        <div><strong>Date:</strong> ${new Date().toISOString().split('T')[0]}</div>
      </div>
      
      <div class="bill-details">
        <div class="detail-section">
          <h4>Customer Information</h4>
          <div class="detail-item"><strong>Name:</strong> ${service.customer_name}</div>
          <div class="detail-item"><strong>Contact:</strong> ${service.mobile_number}</div>
          <div class="detail-item"><strong>Address:</strong> ${service.address || 'N/A'}</div>
        </div>
        
        <div class="detail-section">
          <h4>Device Information</h4>
          <div class="detail-item"><strong>Brand:</strong> ${service.mobile_brand}</div>
          <div class="detail-item"><strong>Model:</strong> ${service.model}</div>
          <div class="detail-item"><strong>IMEI 1:</strong> ${service.imei1}</div>
          ${service.imei2 ? `<div class="detail-item"><strong>IMEI 2:</strong> ${service.imei2}</div>` : ''}
        </div>
      </div>
      
      <h4>Items/Services:</h4>
      <table class="items-table">
        <thead>
          <tr>
            <th>S.No</th>
            <th>Item/Description</th>
            <th>Breakout Info</th>
            <th>Price</th>
            <th>Qty</th>
            <th>Total</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody id="billItemsTable">
          <!-- Items will be populated here -->
        </tbody>
      </table>
      
      <button type="button" class="btn btn--secondary add-item-btn" onclick="addBillItem()">Add Item</button>
      
      <div class="bill-summary">
        <div class="summary-row">
          <span>Subtotal:</span>
          <span id="subtotal">Rs. 0</span>
        </div>
        <div class="summary-row">
          <span>GST/Tax:</span>
          <input type="number" id="taxInput" placeholder="%" style="width: 60px; text-align: right;" oninput="calculateTotal()">
          <span id="taxAmount">Rs. 0</span>
        </div>
        <div class="summary-row total">
          <span>Total:</span>
          <span id="grandTotal">Rs. 0</span>
        </div>
      </div>
      
      <div class="warranty-section">
        <div class="warranty-title">WARRANTY INFORMATION</div>
        <div><strong>Period:</strong> ${service.warranty} months</div>
        <div><strong>Valid From:</strong> ${service.from_date} <strong>To:</strong> ${service.to_date}</div>
      </div>
      
      <div class="bill-footer">
        <div>
          <strong>Terms &amp; Conditions:</strong><br>
          <small>1. Warranty void if device is tampered<br>
          2. No warranty on water damage<br>
          3. Goods once sold will not be taken back</small>
        </div>
        <div class="signature-section">
          <div class="signature-line"></div>
          <div>Authorized Signature</div>
        </div>
      </div>
    </div>
  `;
  
  // Show bill generation section
  document.getElementById('billGeneration').classList.remove('hidden');
  
  // Populate initial item row
  updateBillItemsTable();
}

// Add new bill item
function addBillItem() {
  billItems.push({ item: '', breakout: '', price: 0, quantity: 1, total: 0 });
  updateBillItemsTable();
}

// Remove bill item
function removeBillItem(index) {
  if (billItems.length > 1) {
    billItems.splice(index, 1);
    updateBillItemsTable();
  }
}

// Update bill items table
function updateBillItemsTable() {
  const tableBody = document.getElementById('billItemsTable');
  
  tableBody.innerHTML = billItems.map((item, index) => `
    <tr>
      <td>${index + 1}</td>
      <td>
        <input type="text" value="${item.item}" onchange="updateBillItem(${index}, 'item', this.value)" 
               style="border: none; background: transparent; width: 100%;">
      </td>
      <td>
        <input type="text" value="${item.breakout}" onchange="updateBillItem(${index}, 'breakout', this.value)" 
               style="border: none; background: transparent; width: 100%;">
      </td>
      <td class="text-right">
        <input type="number" value="${item.price}" onchange="updateBillItem(${index}, 'price', parseFloat(this.value) || 0)" 
               style="border: none; background: transparent; width: 80px; text-align: right;">
      </td>
      <td class="text-right">
        <input type="number" value="${item.quantity}" min="1" onchange="updateBillItem(${index}, 'quantity', parseInt(this.value) || 1)" 
               style="border: none; background: transparent; width: 50px; text-align: right;">
      </td>
      <td class="text-right">Rs. ${item.total}</td>
      <td>
        ${billItems.length > 1 ? `<button type="button" class="remove-item-btn" onclick="removeBillItem(${index})">Remove</button>` : ''}
      </td>
    </tr>
  `).join('');
  
  calculateTotal();
}

// Update individual bill item
function updateBillItem(index, field, value) {
  billItems[index][field] = value;
  
  // Recalculate item total
  billItems[index].total = billItems[index].price * billItems[index].quantity;
  
  updateBillItemsTable();
}

// Calculate bill total
function calculateTotal() {
  const subtotal = billItems.reduce((sum, item) => sum + item.total, 0);
  const taxPercentage = parseFloat(document.getElementById('taxInput').value) || 0;
  const taxAmount = (subtotal * taxPercentage) / 100;
  const grandTotal = subtotal + taxAmount;
  
  document.getElementById('subtotal').textContent = `Rs. ${subtotal.toFixed(2)}`;
  document.getElementById('taxAmount').textContent = `Rs. ${taxAmount.toFixed(2)}`;
  document.getElementById('grandTotal').textContent = `Rs. ${grandTotal.toFixed(2)}`;
}

// Print bill
function printBill() {
  if (!currentBillService) {
    alert('No service selected for billing');
    return;
  }
  
  // Trigger browser print
  window.print();
}

// Generate PDF (placeholder function)
function generatePDF() {
  if (!currentBillService) {
    alert('No service selected for billing');
    return;
  }
  
  alert('PDF generation feature would be implemented with a PDF library in production.');
  // In a real application, you would use libraries like jsPDF or Puppeteer
}

// Add CSS for print styles
const style = document.createElement('style');
style.textContent = `
  .service-info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: var(--space-12);
    font-size: var(--font-size-sm);
  }
  
  .service-info-grid > div {
    padding: var(--space-8);
    background: var(--color-bg-1);
    border-radius: var(--radius-sm);
  }
`;
document.head.appendChild(style);